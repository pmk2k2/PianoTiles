package presentation;

import application.Main;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

public class StartViewController extends ViewController<Main> {
    Button startButton;
    Button settingsButton;

    public StartViewController(Main application) {
        super(application);
        rootView = new StartView();
        StartView view = (StartView) rootView;
        startButton= view.startButton;
        settingsButton= view.settingsButton;
        initialize();
    }


    public void initialize() {
        startButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (application != null) {
                    application.switchScene(Scenes.GAME_VIEW);
                }
            }
        });
    }


}
