package presentation;

import javafx.scene.layout.GridPane;


public class GameView extends GridPane {

    public GameView(){

    }
}
