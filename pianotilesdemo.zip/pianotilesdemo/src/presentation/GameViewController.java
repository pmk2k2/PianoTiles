package presentation;

import application.Main;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class GameViewController extends ViewController<Main> {
    private static final int NUM_COLUMNS = 4;
    private static final int NUM_ROWS = 4;
    private static final double TILE_SIZE = 100;
    private Rectangle[][] tiles;

    public GameViewController(Main application) {
        super(application);
        tiles = new Rectangle[NUM_ROWS][NUM_COLUMNS];
        rootView = new GameView();

        initialize();
    }

    public void initialize() {
        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_COLUMNS; col++) {
                Rectangle tile = createTile();
                tiles[row][col] = tile;

            }
        }

    }

    private Rectangle createTile() {
        Rectangle tile = new Rectangle(TILE_SIZE, TILE_SIZE);
        tile.setFill(Color.WHITE);
        return tile;
    }

    private void resetTileColors() {
        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_COLUMNS; col++) {
                tiles[row][col].setFill(Color.WHITE);
            }
        }
    }

    private void handleMouseClick(double x, double y) {
        int col = (int) (x / TILE_SIZE);
        int row = (int) (y / TILE_SIZE);

        if (isValidTile(row, col)) {
            // Handle the correct tile click event
            System.out.println("Mouse Clicked on Correct Tile: (" + col + ", " + row + ")");
        } else {
            // Handle the wrong tile click event
            tiles[row][col].setFill(Color.RED);
            System.out.println("Mouse Clicked on Wrong Tile: (" + col + ", " + row + ")");
            // Handle the loss condition, e.g., end the game
        }
    }

    private void handleKeyPress(KeyCode keyCode) {
        int col = keyCode.ordinal() - KeyCode.A.ordinal();
        int row = NUM_ROWS - 1; // Assuming the key corresponds to the bottom row

        if (isValidTile(row, col)) {
            // Handle the correct key press event
            System.out.println("Key Pressed on Correct Tile: " + keyCode);
        } else {
            // Handle the wrong key press event
            tiles[row][col].setFill(Color.RED);
            System.out.println("Key Pressed on Wrong Tile: " + keyCode);
            // Handle the loss condition, e.g., end the game
        }
    }

    private boolean isValidTile(int row, int col) {
        // Add your logic to determine if the clicked tile is valid for the current game state
        return true; // Modify this condition based on your game rules
    }
}
