package presentation;

public enum Scenes {
    START_VIEW, SETTING_VIEW, GAME_VIEW
}
