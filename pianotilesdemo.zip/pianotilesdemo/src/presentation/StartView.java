package presentation;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.control.Button;



public class StartView extends BorderPane {
    Button startButton;
    Button settingsButton;
    public StartView(){
        startButton= new Button("START");
        settingsButton= new Button("SETTINGS");
        VBox ButtonBar = new VBox();
        ButtonBar.getChildren().addAll(startButton, settingsButton);
        this.setCenter(ButtonBar);
    }
}

