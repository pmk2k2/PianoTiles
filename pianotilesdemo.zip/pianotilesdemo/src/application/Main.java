package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import presentation.GameViewController;
import presentation.Scenes;
import presentation.StartViewController;
import presentation.ViewController;

import java.util.HashMap;

public class Main extends Application {
    private HashMap<Scenes, Pane> scenes;
    private Scene scene;
    private Pane currentScene;


    @Override
    public void init() {
        scenes = new HashMap<>();
    }

    @Override
    public void start(Stage primaryStage) {
        ViewController<Main> controller;
        primaryStage.setTitle("Piano Tiles Game");
        controller = new StartViewController(this);
        scenes.put(Scenes.START_VIEW,  controller.getRootView());

        controller = new GameViewController(this);
        scenes.put(Scenes.GAME_VIEW,  controller.getRootView());

        Pane root = scenes.get(Scenes.START_VIEW);
        scene = new Scene(root,500,800);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public void switchScene(Scenes sceneName) {
        Pane nextScene;

        if (scenes.containsKey(sceneName)) {
            nextScene = scenes.get(sceneName);
            scene.setRoot(nextScene);
            currentScene = nextScene;
        }
    }
    public static void main(String[] args) {
        launch(args);
    }
}
